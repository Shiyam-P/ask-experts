from django.apps import AppConfig


class AsktheexpertsConfig(AppConfig):
    name = 'asktheexperts'
